document.addEventListener('DOMContentLoaded', async function () {

  // ============================================================
  // PLATFORM CONFIGURATION
  // Maps each platform to its domains, auth cookie names, etc.
  // ============================================================
  const PLATFORMS = {
    facebook: {
      label: 'Facebook',
      labelUpper: 'FACEBOOK',
      domains: ['.facebook.com'],
      uidCookie: 'c_user',
      sessionCookie: 'xs',
      tokenCookieName: 'c_user',
      url: 'https://www.facebook.com',
      // Extracts the logged-in user's name from the Facebook page DOM
      getNameFunc: function () {
        try {
          const m = /"NAME":"(.*?)"/.exec(document.documentElement.innerHTML);
          return m ? m[1] : '';
        } catch (e) { return ''; }
      }
    },
    instagram: {
      label: 'Instagram',
      labelUpper: 'INSTAGRAM',
      domains: ['.instagram.com'],
      uidCookie: 'ds_user_id',
      sessionCookie: 'sessionid',
      tokenCookieName: 'sessionid',
      url: 'https://www.instagram.com',
      getNameFunc: function () {
        try {
          const m = /"username":"(.*?)"/.exec(document.documentElement.innerHTML);
          return m ? m[1] : '';
        } catch (e) { return ''; }
      }
    },
    tiktok: {
      label: 'TikTok',
      labelUpper: 'TIKTOK',
      domains: ['.tiktok.com'],
      uidCookie: 'tt_webid_v2',
      sessionCookie: 'sessionid',
      tokenCookieName: 'sessionid',
      url: 'https://www.tiktok.com',
      getNameFunc: function () {
        try {
          const el = document.querySelector('[data-e2e="user-title"]') ||
                     document.querySelector('.tiktok-username');
          return el ? el.textContent.trim() : '';
        } catch (e) { return ''; }
      }
    },
    twitter: {
      label: 'Twitter (X)',
      labelUpper: 'TWITTER',
      domains: ['.twitter.com', '.x.com'],
      uidCookie: 'twid',
      sessionCookie: 'auth_token',
      tokenCookieName: 'auth_token',
      url: 'https://twitter.com',
      getNameFunc: function () {
        try {
          const el = document.querySelector('[data-testid="UserName"] span');
          return el ? el.textContent.trim() : '';
        } catch (e) { return ''; }
      }
    }
  };

  // ============================================================
  // STATE
  // ============================================================
  let savedAccounts = [];
  let currentCookies = [];  // Live cookies from browser for selected platform
  let qrVisible = false;

  // ============================================================
  // DOM REFERENCES
  // ============================================================
  const platformSelect   = document.getElementById('platformSelect');
  const activeDomain     = document.getElementById('activeDomain');
  const cookieTextarea   = document.getElementById('cookieInput');
  const btnImport        = document.getElementById('btnImport');
  const btnQrCode        = document.getElementById('btnQrCode');
  const btnGetToken      = document.getElementById('btnGetToken');
  const btnIdentify      = document.getElementById('btnIdentify');
  const btnNewLogin      = document.getElementById('btnNewLogin');
  const btnExport        = document.getElementById('btnExport');
  const btnClearCookies  = document.getElementById('btnClearCookies');
  const qrSection        = document.getElementById('qrSection');
  const qrImg            = document.getElementById('qrImg');
  const qrModal          = document.getElementById('qrModal');
  const qrModalImg       = document.getElementById('qrModalImg');
  const qrModalTitle     = document.getElementById('qrModalTitle');
  const qrModalClose     = document.getElementById('qrModalClose');
  const statusMsg        = document.getElementById('statusMessage');
  const autoSaveCheckbox = document.getElementById('autoSaveCheckbox');
  const saveLabel        = document.getElementById('saveLabel');
  const accountsList     = document.getElementById('accountsList');

  // Wire up saveLabel click to toggle checkbox (no inline onclick in HTML)
  saveLabel.addEventListener('click', () => { autoSaveCheckbox.checked = !autoSaveCheckbox.checked; chrome.storage.local.set({ autoSave: autoSaveCheckbox.checked }); });

  // ============================================================
  // INIT — Load storage then auto-detect platform
  // ============================================================
  const stored = await chrome.storage.local.get(['savedAccounts', 'autoSave']);
  savedAccounts = stored.savedAccounts || [];
  if (stored.autoSave !== undefined) autoSaveCheckbox.checked = stored.autoSave;

  // Auto-detect which platform the user is currently browsing
  const initTabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (initTabs.length > 0 && initTabs[0].url) {
    for (const [key, plat] of Object.entries(PLATFORMS)) {
      if (plat.domains.some(d => initTabs[0].url.includes(d.replace(/^\./, '')))) {
        platformSelect.value = key;
        break;
      }
    }
  }

  // Update all dynamic labels and load cookies
  // NOTE: called AFTER await so platform auto-detection has already set platformSelect.value
  renderAccountsList();
  await refreshActiveCookies();
  updateDynamicLabels(); // Always called last — after auto-detection settles

  // ============================================================
  // EVENT LISTENERS
  // ============================================================
  platformSelect.addEventListener('change', async () => {
    updateDynamicLabels();
    renderAccountsList();
    qrSection.style.display = 'none';
    qrVisible = false;
    await refreshActiveCookies();
    updateDynamicLabels(); // call again after async completes to be safe
  });

  btnImport.addEventListener('click', handleImport);
  btnQrCode.addEventListener('click', handleQrCode);
  btnGetToken.addEventListener('click', handleGetToken);
  btnIdentify.addEventListener('click', handleIdentify);
  btnNewLogin.addEventListener('click', handleNewLogin);
  btnExport.addEventListener('click', showExportModal);
  btnClearCookies.addEventListener('click', handleClearCookies);

  // Export modal
  document.getElementById('exportModalClose').addEventListener('click', () => {
    document.getElementById('exportModal').style.display = 'none';
  });
  document.getElementById('exportModal').addEventListener('click', (e) => {
    if (e.target.id === 'exportModal') document.getElementById('exportModal').style.display = 'none';
  });
  document.getElementById('btnDoExport').addEventListener('click', handleDoExport);

  autoSaveCheckbox.addEventListener('change', () => {
    chrome.storage.local.set({ autoSave: autoSaveCheckbox.checked });
  });

  // QR Image → open full-size modal
  qrImg.addEventListener('click', () => {
    const pKey = platformSelect.value;
    const platform = PLATFORMS[pKey];
    qrModalImg.src = qrImg.src;
    qrModalTitle.textContent = `${platform.label} — Active Account Cookies`;
    qrModal.style.display = 'flex';
  });

  qrModalClose.addEventListener('click', () => { qrModal.style.display = 'none'; });
  qrModal.addEventListener('click', (e) => { if (e.target === qrModal) qrModal.style.display = 'none'; });

  // ============================================================
  // UI HELPERS
  // ============================================================
  function updateDynamicLabels() {
    const pKey = platformSelect.value;
    const platform = PLATFORMS[pKey];
    if (!platform) return; // Safety guard

    // Update save checkbox label
    saveLabel.textContent = `Save ${platform.label} Account for Easy Login`;

    // Update the new-login button text directly (no inner span)
    btnNewLogin.textContent = `LOGIN TO NEW ${platform.labelUpper} WITH COOKIE OR WITH NO COOKIE`;
  }

  function showStatus(msg, isError = false) {
    statusMsg.textContent = msg;
    statusMsg.className = 'status ' + (isError ? 'error' : 'success');
    setTimeout(() => { statusMsg.textContent = ''; statusMsg.className = 'status'; }, 5000);
  }

  // ============================================================
  // REFRESH ACTIVE COOKIES
  // Reads live cookies from the browser for the selected platform
  // and populates the textarea + auto-saves if enabled.
  // ============================================================
  async function refreshActiveCookies() {
    const pKey = platformSelect.value;
    const platform = PLATFORMS[pKey];
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0] || null;

    // Is the active tab on this platform?
    const isOnPlatform = tab?.url && platform.domains.some(d => tab.url.includes(d.replace(/^\./, '')));

    // Update domain display
    if (isOnPlatform && tab?.url) {
      try { activeDomain.textContent = new URL(tab.url).hostname; }
      catch (e) { activeDomain.textContent = platform.url.replace('https://', ''); }
    } else {
      activeDomain.textContent = platform.url.replace('https://', '');
    }

    // Gather and deduplicate cookies from all platform domains
    let all = [];
    for (const domain of platform.domains) {
      const c = await chrome.cookies.getAll({ domain });
      all = all.concat(c);
    }
    const seen = new Set();
    currentCookies = all.filter(c => { if (seen.has(c.name)) return false; seen.add(c.name); return true; });

    // Check for a real logged-in session (UID auth cookie must exist)
    const uidCookie = currentCookies.find(c => c.name === platform.uidCookie);
    const hasSession = !!uidCookie;

    // Only populate the textarea with cookies when there is an active session.
    // If no session (or no cookies at all), set value to '' so the
    // HTML placeholder attribute is visible instead of a bare ';'.
    if (hasSession && currentCookies.length > 0) {
      cookieTextarea.value = cookiesToRawString(currentCookies);
    } else {
      cookieTextarea.value = '';
    }

    // Auto-save account if enabled and a session exists
    if (autoSaveCheckbox.checked && hasSession && tab) {
      // Save as JSON to preserve domain/path/expiration so they survive browser restarts
      await saveAccountData(pKey, uidCookie.value, cookiesToJSON(currentCookies), tab);
    }
  }

  // ============================================================
  // COOKIE FORMAT CONVERTERS
  // ============================================================

  /** name=value; name2=value2; */
  function cookiesToRawString(cookies) {
    if (!cookies || cookies.length === 0) return '';
    return cookies.map(c => `${c.name}=${c.value}`).join('; ') + ';';
  }

  /** JSON array (pretty-printed) */
  function cookiesToJSON(cookies) {
    if (!cookies || cookies.length === 0) return '[]';
    return JSON.stringify(cookies, null, 2);
  }

  /** Netscape / curl / wget format */
  function cookiesToNetscape(cookies) {
    if (!cookies || cookies.length === 0) return '';
    const lines = [
      '# Netscape HTTP Cookie File',
      '# Generated by smmrug.com | Get Cookie Tool',
      '# https://smmrug.com',
      ''
    ];
    for (const c of cookies) {
      const domain = c.domain || '';
      const inclSub = domain.startsWith('.') ? 'TRUE' : 'FALSE';
      const path    = c.path || '/';
      const secure  = c.secure ? 'TRUE' : 'FALSE';
      const expiry  = c.expirationDate ? Math.round(c.expirationDate) : 0;
      lines.push(`${domain}\t${inclSub}\t${path}\t${secure}\t${expiry}\t${c.name}\t${c.value}`);
    }
    return lines.join('\n');
  }

  /** Essential-only: key auth cookies in raw string format */
  function cookiesToEssential(cookies, pKey) {
    const platform = PLATFORMS[pKey];
    const keyNames = [
      platform.uidCookie, platform.sessionCookie,
      'auth_token', 'sessionid', 'c_user', 'xs', 'ds_user_id', 'twid'
    ];
    const essential = cookies.filter(c => keyNames.includes(c.name));
    return cookiesToRawString(essential.length > 0 ? essential : cookies);
  }

  /** Dispatch to the right formatter */
  function formatCookies(cookies, format, pKey) {
    switch (format) {
      case 'json':      return cookiesToJSON(cookies);
      case 'netscape':  return cookiesToNetscape(cookies);
      case 'essential': return cookiesToEssential(cookies, pKey);
      case 'raw': default: return cookiesToRawString(cookies);
    }
  }

  // ============================================================
  // ACCOUNT PERSISTENCE
  // ============================================================
  async function saveAccountData(pKey, uid, cookieStr, tab) {
    const platform = PLATFORMS[pKey];
    let name = uid; // Default to UID as name

    // Try to get the real name from the page via scripting
    try {
      const isOnPlatform = tab?.url && platform.domains.some(d => tab.url.includes(d.replace(/^\./, '')));
      if (isOnPlatform && tab.url && !tab.url.startsWith('chrome://') && !tab.url.startsWith('about:')) {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: platform.getNameFunc
        });
        const extracted = results?.[0]?.result;
        if (extracted && extracted.trim()) name = extracted.trim();
      }
    } catch (e) {
      console.warn('Name extraction skipped:', e.message);
    }

    // Decode unicode escapes (e.g. from Facebook's "\u00e9")
    try { name = name.replace(/\\u([\dA-Fa-f]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16))); } catch(e) {}

    const existing = savedAccounts.findIndex(a => a.platform === pKey && a.uid === uid);
    const record = { platform: pKey, uid, name, cookie: cookieStr, savedAt: Date.now() };
    if (existing > -1) {
      savedAccounts[existing] = record;
    } else {
      savedAccounts.push(record);
    }
    await chrome.storage.local.set({ savedAccounts });
    renderAccountsList();
  }

  function renderAccountsList() {
    const pKey = platformSelect.value;
    const filtered = savedAccounts.filter(a => a.platform === pKey);
    accountsList.innerHTML = '';
    accountsList.style.display = filtered.length > 0 ? 'block' : 'none';

    for (const acc of filtered) {
      const item = document.createElement('div');
      item.className = 'account-item';

      const nameSpan = document.createElement('span');
      nameSpan.className = 'account-name';
      nameSpan.textContent = `${acc.uid} — ${acc.name !== acc.uid ? acc.name : acc.uid}`;

      const delBtn = document.createElement('button');
      delBtn.className = 'account-delete';
      delBtn.textContent = '×';
      delBtn.title = 'Remove saved account';
      delBtn.onclick = async (e) => {
        e.stopPropagation();
        savedAccounts = savedAccounts.filter(a => !(a.platform === pKey && a.uid === acc.uid));
        await chrome.storage.local.set({ savedAccounts });
        renderAccountsList();
      };

      item.appendChild(nameSpan);
      item.appendChild(delBtn);

      // Click account item → import its cookies
      item.addEventListener('click', async () => {
        cookieTextarea.value = acc.cookie;
        showStatus(`Loading account ${acc.uid}...`);
        await importCookiesFromString(acc.cookie, pKey);
      });

      accountsList.appendChild(item);
    }
  }

  // ============================================================
  // SMART PARSER
  // Detects: JSON array → Netscape → raw string → raw token
  // ============================================================
  function parseCookies(input, pKey) {
    input = input.trim();
    if (!input) return [];

    const platform = PLATFORMS[pKey];
    const defaultDomain = platform.domains[0];
    let cookies = [];

    // 1. JSON Array
    try {
      const parsed = JSON.parse(input);
      if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].name) {
        return parsed.map(c => ({
          domain: c.domain || defaultDomain,
          name: c.name,
          value: c.value,
          path: c.path || '/',
          secure: c.secure !== false,
          sameSite: 'no_restriction',
          expirationDate: c.expirationDate
        }));
      }
    } catch (e) { /* Not JSON */ }

    // 2. Netscape format (tab-separated, 7 columns)
    if (input.includes('\t') && input.split('\n').some(l => l.split('\t').length >= 6)) {
      for (let line of input.split('\n')) {
        line = line.trim();
        if (!line || line.startsWith('#')) continue;
        const p = line.split('\t');
        if (p.length >= 7) {
          cookies.push({ 
            domain: p[0], 
            name: p[5], 
            value: p[6], 
            path: p[2], 
            secure: p[3] === 'TRUE', 
            expirationDate: parseFloat(p[4]) || undefined 
          });
        }
      }
      if (cookies.length > 0) return cookies;
    }

    // 3. Raw string: name=value; name2=value2;
    if (input.includes('=')) {
      for (let part of input.split(';')) {
        part = part.trim();
        if (!part) continue;
        const idx = part.indexOf('=');
        if (idx > -1) {
          const name = part.substring(0, idx).trim();
          const value = part.substring(idx + 1); // preserve full value incl. any '=' chars
          if (name && value) cookies.push({ domain: defaultDomain, name, value, path: '/' });
        }
      }
      if (cookies.length > 0) return cookies;
    }

    // 4. Fallback: treat entire string as a single session token
    // Strict regex: tokens are typically hex, numeric, or base64-like, optionally URL encoded.
    // They should ONLY contain letters, numbers, and allowed characters: - _ % : .
    const isValidToken = /^[a-zA-Z0-9\-_%:\.]+$/.test(input);
    if (input.length > 5 && input.length < 500 && isValidToken) {
      return [{ domain: defaultDomain, name: platform.tokenCookieName, value: input, path: '/' }];
    }

    return [];
  }

  // ============================================================
  // COOKIE OPERATIONS
  // ============================================================
  async function clearCookiesForPlatform(pKey) {
    const platform = PLATFORMS[pKey];
    let count = 0;
    for (const domain of platform.domains) {
      const cookies = await chrome.cookies.getAll({ domain });
      for (const cookie of cookies) {
        const d = cookie.domain.startsWith('.') ? cookie.domain.substring(1) : cookie.domain;
        const url = `${cookie.secure ? 'https' : 'http'}://${d}${cookie.path}`;
        try { await chrome.cookies.remove({ url, name: cookie.name }); count++; } catch (e) {}
      }
    }
    return count;
  }

  async function importCookiesFromString(input, pKey) {
    const platform = PLATFORMS[pKey];
    const parsed = parseCookies(input, pKey);

    if (parsed.length === 0) {
      showStatus('Could not parse cookie format.', true);
      return false;
    }

    await clearCookiesForPlatform(pKey);

    const defaultExpiration = (Date.now() / 1000) + (60 * 60 * 24 * 365 * 5); // 5 years from now

    let ok = 0;
    for (const c of parsed) {
      const domain = c.domain || platform.domains[0];
      const d = domain.startsWith('.') ? domain.substring(1) : domain;
      const url = `https://${d}`;
      try {
        await chrome.cookies.set({
          url, domain, name: c.name, value: c.value,
          path: c.path || '/', secure: true, sameSite: 'no_restriction',
          expirationDate: c.expirationDate || defaultExpiration
        });
        ok++;
      } catch (e) { console.error('Cookie set failed:', c.name, e); }
    }

    showStatus(`✓ Imported ${ok} cookies! Navigating to ${platform.label}...`);

    // Reload platform tab or open a new one
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length > 0) {
      const activeTab = tabs[0];
      let targetTabId;
      if (activeTab.url && platform.domains.some(d => activeTab.url.includes(d.replace(/^\./, '')))) {
        targetTabId = activeTab.id;
      } else {
        const newTab = await chrome.tabs.create({ url: platform.url });
        targetTabId = newTab.id;
      }
      
      // Write tracking state to local storage BEFORE reload/navigate.
      // This MUST happen before chrome.tabs.reload() because Chrome closes
      // the popup immediately on reload, killing any pending sendMessage calls.
      const tracked = (await chrome.storage.local.get('trackedTabs'))?.trackedTabs || {};
      tracked[String(targetTabId)] = { url: platform.url, uidCookie: platform.uidCookie };
      await chrome.storage.local.set({ trackedTabs: tracked });

      // Now reload — popup may close after this, but tracking is already saved
      if (activeTab.url && platform.domains.some(d => activeTab.url.includes(d.replace(/^\./, '')))) {
        chrome.tabs.reload(targetTabId);
      }
    }
    return true;
  }

  // ============================================================
  // BUTTON HANDLERS
  // ============================================================

  // IMPORT button
  async function handleImport() {
    const pKey = platformSelect.value;
    const input = cookieTextarea.value.trim();
    if (!input) { showStatus('Please paste cookies or a token first.', true); return; }
    
    const currentPlatform = PLATFORMS[pKey];
    const parsed = parseCookies(input, pKey);
    
    if (parsed.length === 0) {
      showStatus('Unidentified Cookies Format... Text strings do not match any cookies Format.', true);
      return;
    }

    // Platform Mismatch Check: Ensure the pasted cookies actually belong to the selected platform
    // We only check if the parsed cookie explicitly provides a domain (like JSON or Netscape formats do)
    const matchesCurrent = parsed.some(c => 
      c.domain && currentPlatform.domains.some(d => c.domain.includes(d.replace(/^\./, '')))
    );

    if (!matchesCurrent) {
      // Find out what platform they actually pasted
      let detectedPlatform = null;
      for (const key in PLATFORMS) {
        if (key !== pKey) {
          const match = parsed.some(c => c.domain && PLATFORMS[key].domains.some(d => c.domain.includes(d.replace(/^\./, ''))));
          if (match) { detectedPlatform = PLATFORMS[key].label; break; }
        }
      }
      
      if (detectedPlatform) {
        showStatus(`Error: You pasted ${detectedPlatform} cookies, but Target Platform is set to ${currentPlatform.label}!`, true);
      } else {
        showStatus(`Error: These cookies do not belong to ${currentPlatform.label}!`, true);
      }
      return;
    }

    btnImport.disabled = true;
    btnImport.textContent = '...';
    try { await importCookiesFromString(input, pKey); }
    finally { btnImport.disabled = false; btnImport.textContent = 'IMPORT'; }
  }

  // QRCODE button — generates QR from the ACTIVE account's live cookies
  async function handleQrCode() {
    // Toggle off
    if (qrVisible) {
      qrSection.style.display = 'none';
      qrVisible = false;
      return;
    }

    // Re-read live cookies from browser (not just textarea) — the "active account"
    const pKey = platformSelect.value;
    const platform = PLATFORMS[pKey];
    let liveCookies = [];
    for (const domain of platform.domains) {
      const c = await chrome.cookies.getAll({ domain });
      liveCookies = liveCookies.concat(c);
    }
    const seen = new Set();
    liveCookies = liveCookies.filter(c => { if (seen.has(c.name)) return false; seen.add(c.name); return true; });

    if (liveCookies.length === 0) {
      showStatus(`No active ${platform.label} cookies found.`, true);
      return;
    }

    // Build cookie string — prefer essential auth cookies to keep QR scannable
    const keyCookieNames = [platform.uidCookie, platform.sessionCookie, 'auth_token', 'sessionid', 'c_user', 'xs', 'ds_user_id'];
    const essentialCookies = liveCookies.filter(c => keyCookieNames.includes(c.name));
    const cookiesToEncode = essentialCookies.length > 0 ? essentialCookies : liveCookies;
    const qrData = cookiesToEncode.map(c => `${c.name}=${c.value}`).join('; ') + ';';

    // Generate QR using the qrserver.com API (img src requests bypass CSP restrictions)
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=256x256&ecc=M&data=${encodeURIComponent(qrData)}`;
    qrImg.src = qrUrl;
    qrSection.style.display = 'block';
    qrVisible = true;

    // Also update the textarea to show exactly what's in the QR
    cookieTextarea.value = qrData;
    activeDomain.textContent = platform.url.replace('https://', '');
    showStatus(`QR generated from active ${platform.label} session.`);
  }

  // GET TOKEN button — extracts the key session token/cookie
  async function handleGetToken() {
    const pKey = platformSelect.value;
    const platform = PLATFORMS[pKey];

    // Look in live cookies first, then current cookies state
    let all = [];
    for (const domain of platform.domains) {
      const c = await chrome.cookies.getAll({ domain });
      all = all.concat(c);
    }

    const token = all.find(c => c.name === platform.sessionCookie) ||
                  all.find(c => c.name === platform.uidCookie);

    if (token) {
      cookieTextarea.value = token.value;
      try {
        await navigator.clipboard.writeText(token.value);
        showStatus(`✓ Token "${token.name}" copied to clipboard!`);
      } catch (e) {
        showStatus(`✓ Token "${token.name}" shown in textarea.`);
      }
    } else {
      showStatus(`No ${platform.sessionCookie} token found. Are you logged in?`, true);
    }
  }

  // FORMAT & SORT button — cleans, sorts, and prettifies pasted cookies
  function handleIdentify() {
    const input = cookieTextarea.value.trim();
    if (!input) { showStatus('Please paste cookies to format/sort.', true); return; }
    
    const pKey = platformSelect.value;
    const parsed = parseCookies(input, pKey);
    
    if (parsed.length === 0) {
      showStatus('Unidentified Cookies Format... Text strings do not match any cookies Format.', true);
      return;
    }

    // Identify which platform the cookies actually belong to (based on domain)
    let detectedPlatform = null;
    let belongsToSelected = true;

    const currentPlatform = PLATFORMS[pKey];
    // Check if any cookie domain matches the currently selected platform
    const matchesCurrent = parsed.some(c => 
      c.domain && currentPlatform.domains.some(d => c.domain.includes(d.replace(/^\./, '')))
    );

    if (!matchesCurrent) {
      belongsToSelected = false;
      // Check if it belongs to any OTHER supported platform
      for (const key in PLATFORMS) {
        if (key !== pKey) {
          const match = parsed.some(c => 
            c.domain && PLATFORMS[key].domains.some(d => c.domain.includes(d.replace(/^\./, '')))
          );
          if (match) {
            detectedPlatform = PLATFORMS[key].label;
            break;
          }
        }
      }
    }
    
    // Sort by domain, then name
    parsed.sort((a, b) => {
      const d1 = a.domain || '';
      const d2 = b.domain || '';
      if (d1 === d2) return (a.name || '').localeCompare(b.name || '');
      return d1.localeCompare(d2);
    });

    // Format back to chosen format so the user can clearly read it
    const format = document.getElementById('sortFormatSelect').value || 'json';
    cookieTextarea.value = formatCookies(parsed, format, pKey);

    let statusMsg = `✓ Identified, sorted & formatted ${parsed.length} cookies!`;
    if (!belongsToSelected) {
      if (detectedPlatform) {
        statusMsg = `✓ Identified as ${detectedPlatform} cookies (Mismatch with selected platform).`;
      } else {
        statusMsg = `✓ Identified ${parsed.length} cookies, but they are not from any supported platform.`;
      }
    }

    showStatus(statusMsg);
  }

  // LOGIN TO NEW PLATFORM button — clears all cookies then opens fresh platform tab
  async function handleNewLogin() {
    const pKey = platformSelect.value;
    const platform = PLATFORMS[pKey];
    btnNewLogin.disabled = true;
    try {
      // Clear inverted icon tracking directly in local storage
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs.length > 0) {
        const tracked = (await chrome.storage.local.get('trackedTabs'))?.trackedTabs || {};
        delete tracked[String(tabs[0].id)];
        await chrome.storage.local.set({ trackedTabs: tracked });
        chrome.action.setIcon({ tabId: tabs[0].id, path: { "128": "icon_128.png" } }).catch(e => {});
      }

      await clearCookiesForPlatform(pKey);
      chrome.tabs.create({ url: platform.url });
      qrSection.style.display = 'none';
      qrVisible = false;
      cookieTextarea.value = '';
      activeDomain.textContent = platform.url.replace('https://', '');
      showStatus(`Cookies cleared. Opening ${platform.label} login...`);
    } finally {
      btnNewLogin.disabled = false;
    }
  }

  // ============================================================
  // EXPORT — Modal + File Download
  // All 3 export scopes are fully compliant with Chrome and Firefox
  // MV3 extension policies. File download uses Blob URL + anchor
  // click (no 'downloads' permission required).
  // ============================================================

  function showExportModal() {
    document.getElementById('exportModal').style.display = 'flex';
  }

  async function handleDoExport() {
    const pKey = platformSelect.value;
    const platform = PLATFORMS[pKey];
    const format = document.querySelector('input[name="exportFormat"]:checked')?.value || 'raw';
    const scope  = document.querySelector('input[name="exportScope"]:checked')?.value  || 'platform';
    const doExportBtn = document.getElementById('btnDoExport');

    doExportBtn.disabled = true;
    doExportBtn.textContent = 'Preparing...';

    try {
      let cookiesToExport = [];
      let scopeLabel    = '';
      let platformLabel = '';

      // ── Scope: Active Tab only ──
      if (scope === 'activetab') {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        const tab = tabs[0];
        if (!tab?.url) { showStatus('No active tab found.', true); return; }
        // Use the exact URL of the active tab to get ALL cookies applicable to it (including dot-prefixed domains)
        cookiesToExport = await chrome.cookies.getAll({ url: tab.url });
        scopeLabel    = 'ActiveTab';
        platformLabel = platform.label;

      // ── Scope: All cookies from selected platform ──
      } else if (scope === 'platform') {
        for (const domain of platform.domains) {
          cookiesToExport = cookiesToExport.concat(await chrome.cookies.getAll({ domain }));
        }
        const seen = new Set();
        cookiesToExport = cookiesToExport.filter(c => { if (seen.has(c.name)) return false; seen.add(c.name); return true; });
        scopeLabel    = 'AllCookies';
        platformLabel = platform.label;

      // ── Scope: All cookies from ALL 4 platforms ──
      } else if (scope === 'all') {
        for (const [, plat] of Object.entries(PLATFORMS)) {
          for (const domain of plat.domains) {
            cookiesToExport = cookiesToExport.concat(await chrome.cookies.getAll({ domain }));
          }
        }
        // Deduplicate by domain+name pair
        const seen = new Set();
        cookiesToExport = cookiesToExport.filter(c => {
          const key = `${c.domain}::${c.name}`;
          if (seen.has(key)) return false; seen.add(key); return true;
        });
        scopeLabel    = 'AllCookies';
        platformLabel = 'AllPlatforms';
      }

      if (cookiesToExport.length === 0) {
        showStatus('No cookies found for the selected scope.', true);
        return;
      }

      // ── Sort properly by domain, then by name ──
      cookiesToExport.sort((a, b) => {
        const d1 = a.domain || '';
        const d2 = b.domain || '';
        if (d1 === d2) return (a.name || '').localeCompare(b.name || '');
        return d1.localeCompare(d2);
      });

      const formatLabel = { raw: 'RawString', json: 'JSON', netscape: 'Netscape', essential: 'EssentialOnly' }[format] || 'Cookies';
      const content  = formatCookies(cookiesToExport, format, pKey);
      const filename = `${platformLabel}_${scopeLabel}_${formatLabel}_cookies.txt`;

      downloadAsText(content, filename);
      document.getElementById('exportModal').style.display = 'none';
      showStatus(`✓ Exported ${cookiesToExport.length} cookies → ${filename}`);

    } catch (e) {
      console.error('Export failed:', e);
      showStatus('Export failed. See console for details.', true);
    } finally {
      doExportBtn.disabled = false;
      doExportBtn.textContent = '⬇ Download .txt File';
    }
  }

  /** Download a text string as a .txt file — Blob URL method (no downloads permission needed) */
  function downloadAsText(content, filename) {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 600);
  }

  // CLEAR COOKIES button
  async function handleClearCookies() {
    const pKey = platformSelect.value;
    const platform = PLATFORMS[pKey];
    btnClearCookies.disabled = true;
    try {
      const count = await clearCookiesForPlatform(pKey);
      cookieTextarea.value = '';
      qrSection.style.display = 'none';
      qrVisible = false;
      activeDomain.textContent = platform.url.replace('https://', '');
      showStatus(`✓ Cleared ${count} cookies for ${platform.label}.`);
      // Reload if already on that platform
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs.length > 0 && tabs[0].url && platform.domains.some(d => tabs[0].url.includes(d.replace(/^\./, '')))) {
        chrome.tabs.reload(tabs[0].id);
      }
    } catch (e) {
      showStatus('Error clearing cookies.', true);
    } finally {
      btnClearCookies.disabled = false;
    }
  }
});
