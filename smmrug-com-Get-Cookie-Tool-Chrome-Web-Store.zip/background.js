// smmrug.com | Get Cookie Tool — Chrome MV3 background service worker
// Uses chrome.storage.local for tab tracking (survives SW restarts + popup closes)

chrome.runtime.onInstalled.addListener(() => {
    console.log("smmrug.com | Get Cookie Tool installed.");
});

// ── Helpers to read/write tracked tabs ──
async function getTrackedTabs() {
    try {
        const data = await chrome.storage.local.get('trackedTabs');
        return data.trackedTabs || {};
    } catch (e) { return {}; }
}

async function setTrackedTabs(obj) {
    try { await chrome.storage.local.set({ trackedTabs: obj }); } catch(e) {}
}

// ── Message listener (for clearInverted and legacy imported) ──
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'imported') {
        getTrackedTabs().then(tabs => {
            tabs[String(request.tabId)] = { url: request.url, uidCookie: request.uidCookie };
            setTrackedTabs(tabs);
        });
    }
    if (request.action === 'clearInverted') {
        getTrackedTabs().then(tabs => {
            delete tabs[String(request.tabId)];
            setTrackedTabs(tabs);
        });
        chrome.action.setIcon({
            tabId: request.tabId,
            path: { "128": "icon_128.png" }
        }).catch(() => {});
    }
});

// ── Tab update listener — verify login after page fully loads ──
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if (changeInfo.status !== 'complete') return;
    
    const tracked = await getTrackedTabs();
    const info = tracked[String(tabId)];
    if (!info) return;

    let targetHost;
    try { targetHost = new URL(info.url).hostname.replace('www.', ''); } catch(e) { return; }
    
    if (tab.url && tab.url.includes(targetHost)) {
        try {
            const cookies = await chrome.cookies.getAll({ url: info.url });
            const hasAuth = cookies.some(c => c.name === info.uidCookie);
            
            if (hasAuth) {
                await chrome.action.setIcon({
                    tabId: tabId,
                    path: { "128": "icon_success_128.png" }
                });
            } else {
                await chrome.action.setIcon({
                    tabId: tabId,
                    path: { "128": "icon_128.png" }
                });
            }
        } catch (e) { console.error('Error verifying login:', e); }
    } else {
        delete tracked[String(tabId)];
        await setTrackedTabs(tracked);
        try {
            await chrome.action.setIcon({
                tabId: tabId,
                path: { "128": "icon_128.png" }
            });
        } catch(e) {}
    }
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
    const tracked = await getTrackedTabs();
    if (tracked[String(tabId)]) {
        delete tracked[String(tabId)];
        await setTrackedTabs(tracked);
    }
});
